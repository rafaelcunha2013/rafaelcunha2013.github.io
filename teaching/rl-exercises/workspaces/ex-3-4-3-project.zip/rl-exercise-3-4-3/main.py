from algorithms.solvers.bellmanequationsolver import BellmanEquationSolver
from algorithms.solvers.dynamicprogrammingsolver import DynamicProgrammingSolver
from util.my_mdp import create_my_mdp, create_my_policy


def main() -> None:
    """
    Starting point of the program: your MDP of part (a), then parts (b) and (c).
    """
    mdp = create_my_mdp()

    print("Policy evaluation in matrix form (b)...")
    value_function = BellmanEquationSolver(mdp).policy_evaluation(create_my_policy())
    print("Value Function for your policy:", value_function)

    print("Value Iteration (c)...")
    optimal_policy, value_function = DynamicProgrammingSolver(mdp).value_iteration()
    print("Optimal Policy:", optimal_policy)
    print("Optimal Value Function:", value_function)

    print("Policy Iteration (c)...")
    optimal_policy, value_function = DynamicProgrammingSolver(mdp).policy_iteration()
    print("Optimal Policy:", optimal_policy)
    print("Optimal Value Function:", value_function)


if __name__ == "__main__":
    main()
