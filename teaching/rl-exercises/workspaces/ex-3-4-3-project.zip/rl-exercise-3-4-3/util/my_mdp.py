"""Your MDP and policy (Exercise 3.4.3, part (a))."""
import numpy as np
from mdp.mdp import MDP
from mdp.reward_function import RewardFunction
from mdp.transition_function import TransitionFunction
from util.discretepolicy import DiscretePolicy


def create_my_mdp() -> MDP:
    """
    Creates the MDP you designed in part (a).

    :return: An MDP object with your states, actions, transition function, reward function and discount factor.
    """
    pass


def create_my_policy() -> DiscretePolicy:
    """
    Creates a stochastic policy pi(a|s) for your MDP, to evaluate in part (b).
    (DiscretePolicy().set_action_probabilities(state, [...]) sets the probabilities for one state.)

    :return: A DiscretePolicy object.
    """
    pass
