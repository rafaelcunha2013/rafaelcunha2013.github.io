import gymnasium as gym
from loguru import logger
from stable_baselines3 import PPO
from algorithms.control.actorcriticagent import ActorCriticAgent
from algorithms.control.reinforceagent import ReinforceAgent
from util.metricstrackercallback import MetricsTrackerCallback
from util.metrictracker import MetricsTracker
from stable_baselines3.common.callbacks import StopTrainingOnMaxEpisodes


def env_interaction(env_str: str,
                    agent_type: str,
                    num_episodes: int,
                    tracker: MetricsTracker,
                    learning_rate_actor: float,
                    learning_rate_critic: float) -> None:
    """
    Train RL algorithms and track performance.

    :param env_str: environment name as a string.
    :param agent_type: type of agent to be trained.
    :param num_episodes: number of training episodes.
    :param tracker: tracks performance of behavioral policy.
    :param learning_rate_actor: learning rate for policy approximation.
    :param learning_rate_critic: learning rate for value function approximation.
    """
    logger.info(f"Training {agent_type} on {env_str} for {num_episodes} episodes.")

    env = gym.make(env_str, render_mode='rgb_array')
    
    obs_space = env.observation_space
    action_space = env.action_space
    agent = None
    if agent_type == "ACTOR-CRITIC-AGENT":
        agent = ActorCriticAgent(obs_space, action_space,
                                 learning_rate_actor=learning_rate_actor,
                                 learning_rate_critic=learning_rate_critic)
    elif agent_type == "REINFORCE":
        agent = ReinforceAgent(obs_space, action_space,
                               learning_rate_actor=learning_rate_actor,
                               learning_rate_critic=learning_rate_critic)
    else:
        raise ValueError("Invalid agent type")

    for episode in range(num_episodes):
        episode_return = 0
        obs, info = env.reset()

        # Start episode loop
        while True:
            action = agent.policy(obs)
            next_obs, reward, terminated, truncated, info = env.step(action)

            agent.add_transition(obs, action, reward, next_obs, terminated or truncated)
            agent.update()

            episode_return += reward
            obs = next_obs

            if terminated or truncated:
                # Record episodic return for the policy
                logger.info(f"Episode finished, {episode_return}")
                tracker.record_metric(
                    metric_name="return",
                    agent_id=agent_type,
                    idx=episode,
                    value=episode_return
                )
                break

    env.close()


def train_ppo(env_str: str, tracker: MetricsTracker, num_episodes: int) -> None:
    """
    Train your PPO algorithm here and track performance using MetricsTracker.
    Use the MetricsTrackerCallback when running the learn method.
    
    :param env_str: environment name as a string.
    :param tracker: metric tracker.
    :param num_episodes:
    """
    logger.info(f"Training PPO on {env_str}")

    env = gym.make(env_str, render_mode='rgb_array')

    # Define the callbacks
    metrics_tracker_callback = MetricsTrackerCallback(tracker)
    max_episode_callback = StopTrainingOnMaxEpisodes(max_episodes=num_episodes, verbose=0)

    # add code here

    env.close()


if __name__ == "__main__":
    metric_tracker = MetricsTracker()

    num_runs = 1
    n_episodes = 50
    for _ in range(num_runs):
        # Train each algorithm per run. `env_interaction` or `train_ppo` for PPO.
        pass

    metric_tracker.plot_metric("return", "return.png", smoothing_window=50)
