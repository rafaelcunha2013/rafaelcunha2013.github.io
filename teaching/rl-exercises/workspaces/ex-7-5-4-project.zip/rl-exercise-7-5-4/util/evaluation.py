from typing import Union
import gymnasium as gym
from algorithms.control.abstractagent import AbstractAgent
from algorithms.control.sb_adapter import StableBaselinesAdapter
from algorithms.control.tabularagent import TabularAgent
from util.metrictracker import MetricsTracker


def evaluate_target_policy(env: gym.Env,
                           agent: Union[TabularAgent, StableBaselinesAdapter],
                           tracker: MetricsTracker,
                           episode_idx: int) -> float:
    episode_return = 0
    obs, info = env.reset()

    # Can be extended to return the avg+std return for multiple episodes but for the purposes of the
    # assignment we are interested in one evaluation episode since we directly want to compare the
    # behavioral and target policy.
    while True:
        action = agent.target_policy(obs)
        next_obs, reward, terminated, truncated, info = env.step(action)
        # Consider falling from the Cliff as a terminal state
        if reward == -100:
            terminated = True

        episode_return += reward
        obs = next_obs

        if terminated or truncated:
            tracker.record_metric(metric_name="return", agent_id=agent.agent_type, idx=episode_idx, value=episode_return)
            break

    return episode_return
