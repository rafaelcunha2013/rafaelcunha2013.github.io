from typing import Any, Generator, Tuple
import torch
from torch import Tensor


class RolloutBuffer:
    """
    Simple rollout buffer for on-policy RL algorithms.
    Stores transitions and provides batched retrieval.
    Discards oldest transitions when capacity is exceeded.
    """

    def __init__(self, capacity: int, device: torch.device) -> None:
        """
        Initialize empty buffer.

        :param capacity: Max number of transitions to store.
        :param device: Torch device to store tensors on.
        """
        self.states = []
        self.actions = []
        self.rewards = []
        self.next_states = []
        self.dones = []
        self.capacity = capacity
        self.device = device

    def push(
        self,
        state,
        action,
        reward,
        next_state,
        done,
    ) -> None:
        """
        Add a transition to the buffer, discarding oldest if capacity is reached.
        """

        def ensure_tensor(x, dtype, device):
            if isinstance(x, torch.Tensor):
                return x.to(dtype=dtype, device=device)
            return torch.tensor(x, dtype=dtype, device=device)

        # Append new transition
        self.states.append(ensure_tensor(state, torch.float32, self.device))
        self.actions.append(ensure_tensor(action, torch.float32, self.device))
        self.rewards.append(ensure_tensor(reward, torch.float32, self.device))
        self.next_states.append(ensure_tensor(next_state, torch.float32, self.device))
        self.dones.append(ensure_tensor(done, torch.float32, self.device))

        # Discard oldest if capacity exceeded
        while len(self.states) > self.capacity:
            self.states.pop(0)
            self.actions.pop(0)
            self.rewards.pop(0)
            self.next_states.pop(0)
            self.dones.pop(0)

    def get(self, batch_size: int) -> Generator[tuple[Tensor, Tensor, Tensor, Tensor, Tensor], Any, None]:
        """
        Yield mini-batches of stored transitions.

        :param batch_size: Size of each mini-batch.
        :return: Generator of (state, action, reward, next_state, done).
        """
        states = torch.stack(self.states)
        actions = torch.stack(self.actions)
        rewards = torch.stack(self.rewards)
        next_states = torch.stack(self.next_states)
        dones = torch.stack(self.dones)

        for start in range(0, len(states), batch_size):
            end = start + batch_size
            yield (
                states[start:end],
                actions[start:end],
                rewards[start:end],
                next_states[start:end],
                dones[start:end],
            )

    def latest(self) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
        """
        Retrieve the latest transition added to the buffer without removing it.
        :return: The latest transition tuple (state, action, reward, next_state, done).
        """
        assert len(self.states) > 0, "No transitions in buffer"
        return (
            self.states[-1],
            self.actions[-1],
            self.rewards[-1],
            self.next_states[-1],
            self.dones[-1],
        )

    def clear(self) -> None:
        """
        Clear the buffer.
        """
        self.states.clear()
        self.actions.clear()
        self.rewards.clear()
        self.next_states.clear()
        self.dones.clear()

    def __len__(self) -> int:
        """
        :return: Number of stored transitions.
        """
        return len(self.states)
