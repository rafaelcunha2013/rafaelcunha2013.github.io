
from abc import ABC, abstractmethod
from typing import Union
import gymnasium as gym
import numpy as np
import torch
from torch import nn
from algorithms.control.abstractagent import AbstractAgent
from models.mlp import MLP
from models.stochastic_policy_network import StochasticPolicyNetwork
from util.device import fetch_device



class BasePGAgent(AbstractAgent, ABC):
    """
    Base class for policy-gradient agents. Builds common networks and utilities.

    Subclasses must implement the `update(...)` method.
    """

    def __init__(self,
                 state_space: gym.spaces.Box,
                 action_space: gym.spaces.Box,
                 learning_rate_actor: float,
                 learning_rate_critic: float,
                 discount_factor: float = 0.99):
        super().__init__(state_space, action_space)

        self.device = fetch_device()

        # Actor (policy) and Critic (value function)
        self.policy_net = StochasticPolicyNetwork(input_size=state_space.shape[0],
                                              output_size=action_space.shape[0]).to(self.device)

        # Critic returns a single scalar per state
        self.value_fun = MLP(input_size=state_space.shape[0], output_size=1).to(self.device)

        self.lr_actor = learning_rate_actor
        self.lr_critic = learning_rate_critic
        self.discount_factor = discount_factor

    def policy(self, state: np.ndarray) -> np.ndarray:
        """Return action for a single observation (numpy input -> numpy output)."""
        state_t = torch.from_numpy(state).to(device=self.device, dtype=torch.float32)
        action_t, _ = self.policy_net.sample_action(state_t)
        return action_t.cpu().numpy()

    def save(self, file_path: str = "./") -> None:
        torch.save(self.policy_net.state_dict(), file_path + "actor_model.pth")
        torch.save(self.value_fun.state_dict(), file_path + "critic_model.pth")

    def load(self, file_path: str = "./") -> None:
        self.policy_net.load_state_dict(torch.load(file_path + "actor_model.pth", map_location=self.device))
        self.value_fun.load_state_dict(torch.load(file_path + "critic_model.pth", map_location=self.device))

    def add_transition(self,
                       state: Union[torch.Tensor, np.ndarray],
                       action: Union[torch.Tensor, np.ndarray],
                       reward: Union[torch.Tensor, np.ndarray],
                       next_state: Union[torch.Tensor, np.ndarray],
                       done: bool) -> None:
        state_t = torch.as_tensor(state, device=self.device, dtype=torch.float32)
        action_t = torch.as_tensor(action, device=self.device, dtype=torch.float32)
        reward_t = torch.as_tensor(reward, device=self.device, dtype=torch.float32)
        next_state_t = torch.as_tensor(next_state, device=self.device, dtype=torch.float32)
        done_t = torch.as_tensor(done, device=self.device, dtype=torch.float32)

        self.buf.push(state_t, action_t, reward_t, next_state_t, done_t)

    @abstractmethod
    def update(self) -> bool:
        """Perform training step. Return True if optimization happened."""
        pass
