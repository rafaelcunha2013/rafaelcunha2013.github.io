import torch
import gymnasium as gym
from algorithms.control.basepgagent import BasePGAgent
from util.rollout_buffer import RolloutBuffer


class ActorCriticAgent(BasePGAgent):
    """
    One-step Actor-Critic agent that integrates the trainer logic.

    This implements a simple one-step actor-critic update where the critic
    estimates V(s) and actor is updated with the TD(0) advantage.

    Note that the standard formulation of the A2C algorithm
    assumes memory_size=1, that is the update rule is applied every timestep.
    If memory_size > 1 then this is not the case and the agent will wait
    until the rolloutbuffer is filled.
    """

    def __init__(self,
                 state_space: gym.spaces.Box,
                 action_space: gym.spaces.Box,
                 learning_rate_actor: float = 1e-4,
                 learning_rate_critic: float = 1e-3,
                 discount_factor: float = 0.99,
                 memory_size: int = 1,
                 batch_size: int = 1):
        super().__init__(state_space, action_space, learning_rate_actor, learning_rate_critic, discount_factor)

        self.batch_size = int(batch_size)
        self._memory_size = memory_size

        self.buf = RolloutBuffer(capacity=memory_size, device=self.device)

        self.policy_optimizer = torch.optim.Adam(self.policy_net.parameters(), lr=self.lr_actor)
        self.value_optimizer = torch.optim.Adam(self.value_fun.parameters(), lr=self.lr_critic)

    def _compute_loss(self) -> torch.Tensor:
        # Implement this method
        # Note that the buffer yields a mini-batch of trajectories e.g.
        # for states, actions, rewards, next_states, dones in self.buf.get(self.batch_size):
        pass

    def update(self) -> bool:
        # Train when the buffer is filled
        if len(self.buf) >= self._memory_size:
            loss = self._compute_loss()
            # Add optimization step
            self.buf.clear()  # clear after update
            return True

        return False
