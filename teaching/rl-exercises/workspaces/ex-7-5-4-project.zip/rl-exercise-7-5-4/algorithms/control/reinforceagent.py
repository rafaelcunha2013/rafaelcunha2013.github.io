import gymnasium as gym
import torch
import torch.nn as nn
from algorithms.control.basepgagent import BasePGAgent
from util.rollout_buffer import RolloutBuffer


class ReinforceAgent(BasePGAgent):
    """
    REINFORCE with baseline integrated.

    Collects full-episode trajectories in a buffer and performs updates
    only at the end of each episode (done=True).
    """

    def __init__(self,
                 state_space: gym.spaces.Box,
                 action_space: gym.spaces.Box,
                 learning_rate_actor: float = 1e-4,
                 learning_rate_critic: float = 1e-3,
                 discount_factor: float = 0.99,
                 memory_size: int = 10_000):
        super().__init__(state_space, action_space, learning_rate_actor, learning_rate_critic, discount_factor)

        self.buf = RolloutBuffer(capacity=memory_size, device=self.device)

        self.policy_optimizer = torch.optim.Adam(self.policy_net.parameters(), lr=self.lr_actor)
        self.critic_optimizer = torch.optim.Adam(self.value_fun.parameters(), lr=self.lr_critic)

    def _compute_returns(self, rewards: torch.Tensor) -> torch.Tensor:
        G = torch.zeros_like(rewards)
        cumulative = 0.0
        for t in reversed(range(len(rewards))):
            cumulative = rewards[t] + self.discount_factor * cumulative
            G[t] = cumulative
        return G

    def _compute_loss(self) -> torch.Tensor:
        # Implement this method
        pass

    def update(self) -> bool:
        # Only update at the end of an episode
        _, _, _, _, done = self.buf.latest()
        if done:
            loss = self._compute_loss()
            # Add optimization step
            self.buf.clear()  # clear buffer after update
            return True
        return False
