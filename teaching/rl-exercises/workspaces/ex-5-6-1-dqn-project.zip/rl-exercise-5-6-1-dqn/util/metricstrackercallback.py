import numpy as np
from stable_baselines3.common.callbacks import BaseCallback
from loguru import logger

from util.metrictracker import MetricsTracker


class MetricsTrackerCallback(BaseCallback):
    """
    Stable Baselines callback to track and record the agent's performance using the MetricsTracker.
    """

    def __init__(self, tracker: MetricsTracker, agent_id: str = "PPO", verbose: int = 0):
        """
        :param tracker: The MetricsTracker instance for tracking policy metrics.
        :param agent_id: The identifier for the agent (default: "PPO").
        :param verbose: Verbosity level.
        """
        super().__init__(verbose)
        self.agent_id = agent_id
        self.tracker = tracker
        self.episode_reward = 0.0
        self.episode_idx = 0
        self.highest_avg_return = float('-inf')

    def _on_training_start(self) -> None:
        """
        Initialize metrics tracking when training starts.
        """
        self.episode_reward = 0.0
        self.highest_avg_return = float('-inf')
        self.episode_idx = 0

    def _on_step(self) -> bool:
        """
        Called after each call to `env.step()`.
        Tracks rewards and detects episode endings.
        """
        reward = self.locals['rewards']
        dones = self.locals['dones']

        # Support both numpy arrays and floats
        self.episode_reward += reward.item() if isinstance(reward, np.ndarray) else reward

        if np.any(dones):
            self._on_episode_end()

        return True

    def _on_episode_end(self) -> None:
        """
        Record the episode's return and check for best performance.
        """
        logger.info(f"[{self.agent_id}] Episode {self.episode_idx} finished, return={self.episode_reward:.2f}")

        # Record return in tracker
        self.tracker.record_metric(
            metric_name="return",
            agent_id=self.agent_id,
            idx=self.episode_idx,
            value=self.episode_reward
        )

        # Get the current mean and standard error
        mean_return, _, _ = self.tracker.get_mean_se(
            "return", self.agent_id, self.episode_idx
        )

        if not np.isnan(mean_return) and mean_return > self.highest_avg_return:
            self.highest_avg_return = mean_return
            logger.info(f"[{self.agent_id}] New best mean return: {mean_return:.2f}")

        # Reset episode reward, increment episode index
        self.episode_reward = 0.0
        self.episode_idx += 1

    def _on_training_end(self) -> None:
        """
        Called when training ends.
        """
        logger.info(
            f"Training finished for {self.agent_id}. "
            f"Highest mean return: {self.highest_avg_return:.2f}"
        )
