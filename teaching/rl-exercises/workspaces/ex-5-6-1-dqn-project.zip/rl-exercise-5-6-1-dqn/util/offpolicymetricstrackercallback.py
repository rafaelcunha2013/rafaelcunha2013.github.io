import numpy as np
import gymnasium as gym
from stable_baselines3.common.callbacks import BaseCallback
from loguru import logger
from algorithms.control.sb_adapter import StableBaselinesAdapter
from util.evaluation import evaluate_target_policy
from util.metrictracker import MetricsTracker


class OffPolicyMetricsTrackerCallback(BaseCallback):
    """
    Stable Baselines callback to track and record the agent's performance using the MetricsTracker.
    Additionally, it runs the evaluate_target_policy function at the end of each episode.
    """

    def __init__(self,
                 behavioral_tracker: MetricsTracker,
                 target_tracker: MetricsTracker,
                 eval_env: gym.Env,
                 agent_id: str = "DQN", verbose: int = 0):
        """
        Constructor for StableBaselinesMetricsCallback.

        :param behavioral_tracker: The MetricsTracker instance for tracking behavioral policy metrics.
        :param target_tracker: The MetricsTracker instance for tracking target policy metrics.
        :param eval_env: The evaluation environment.
        :param agent_id: The identifier for the agent (default: "DQN").
        :param verbose: Verbosity level.
        """
        super().__init__(verbose)
        self.agent_id = agent_id
        self.behavioral_tracker = behavioral_tracker
        self.target_tracker = target_tracker
        self.eval_env = eval_env
        self.episode_reward = 0
        self.episode_idx = 0  # Track the current episode index
        self.highest_avg_return = float('-inf')

    def _on_training_start(self) -> None:
        """
        Initialize metrics tracking when training starts.
        """
        self.episode_reward = 0
        self.highest_avg_return = float('-inf')
        self.episode_idx = 0

    def _on_step(self) -> bool:
        """
        This method will be called after each call to `env.step()`.
        Tracks the reward received during each step.

        :return: If the callback returns False, training is aborted early.
        """
        reward = self.locals['rewards']
        dones = self.locals['dones']
        self.episode_reward += reward.item() if isinstance(reward, np.ndarray) else reward

        if np.any(dones):
            self._on_episode_end()

        return True

    def _on_episode_end(self) -> None:
        """
        Record the episode's return and check if the agent achieved a new highest average return.
        """
        # Record the return for the behavioral policy
        self.behavioral_tracker.record_metric(
            metric_name="return",
            agent_id=self.agent_id,
            idx=self.episode_idx,
            value=self.episode_reward
        )

        # Get the current mean and standard error return for this episode
        mean_return, _, _ = self.behavioral_tracker.get_mean_se(
            "return", self.agent_id, self.episode_idx
        )

        if not np.isnan(mean_return) and mean_return > self.highest_avg_return:
            self.highest_avg_return = mean_return

        # Wrap the trained model into a StableBaselinesAdapter
        agent = StableBaselinesAdapter(self.model)
        agent.agent_type = self.agent_id

        # Evaluate the target policy using the provided evaluation environment
        evaluate_target_policy(self.eval_env, agent, self.target_tracker, self.episode_idx)

        # Reset the episode reward
        self.episode_reward = 0
        self.episode_idx += 1  # Increment the episode index

    def _on_training_end(self) -> None:
        # Optionally log or save tracker data
        logger.info(f"Training ended. Highest mean return achieved: {self.highest_avg_return:.2f}")
