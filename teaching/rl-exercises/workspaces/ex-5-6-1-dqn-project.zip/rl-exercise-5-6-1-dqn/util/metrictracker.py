import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
import os
from typing import Union, SupportsFloat, Tuple
import numpy as np
from matplotlib import pyplot as plt
import pandas as pd
import seaborn as sns
import matplotlib.patheffects as pe
import traceback
import scipy.stats as st
from matplotlib.ticker import MaxNLocator


class MetricsTracker:
    """
    Object for recording various metrics across multiple runs.
    Tracks the mean and standard error of each metric, aggregated over multiple runs.
    """

    def __init__(self):
        # Use a more efficient data structure: DataFrame for storage
        self._metrics_df = pd.DataFrame(columns=['metric', 'agent', 'idx', 'value', 'run_id'])
        self._next_run_id = 0
        # Default save path for plots
        self.save_path = "./"
        # Cache for processed data to avoid recomputation
        self._data_cache = {}

    def set_save_path(self, path: str) -> None:
        self.save_path = path

    def record_metric(self,
                      metric_name: str,
                      agent_id: str,
                      idx: int,
                      value: Union[float, int, SupportsFloat]) -> None:
        """
        Record a value for a specific metric, agent, and episode (idx)
        """
        # Invalidate cache since we're adding new data
        self._data_cache.clear()
        
        # Add the new record to the DataFrame
        new_record = pd.DataFrame({
            'metric': [metric_name],
            'agent': [agent_id],
            'idx': [idx],
            'value': [float(value)],
            'run_id': [self._next_run_id]
        })
        
        new_record = new_record.dropna(axis=1, how='all')
        self._metrics_df = pd.concat([self._metrics_df, new_record], ignore_index=True)

    def start_new_run(self) -> None:
        """
        Start a new run (increment run ID)
        """
        self._next_run_id += 1

    def get_mean_se(self,
                    metric_name: str,
                    agent_id: str,
                    idx: int) -> Tuple[float, float, float]:
        """
        Compute the mean and standard error (SEM) for a given metric, agent, and episode
        Returns (mean, mean - SEM, mean + SEM)
        """
        # Filter the DataFrame for the specific metric, agent, and idx
        mask = ((self._metrics_df['metric'] == metric_name) & 
                (self._metrics_df['agent'] == agent_id) & 
                (self._metrics_df['idx'] == idx))
        
        values = self._metrics_df.loc[mask, 'value'].values
        
        if len(values) == 0:
            return float('nan'), float('nan'), float('nan')

        mean = float(np.mean(values))
        n = len(values)

        if n <= 1:
            se = 0.0
        else:
            std = float(np.std(values, ddof=1))
            se = std / np.sqrt(n)
        lower = mean - se
        upper = mean + se
        return mean, lower, upper

    def _get_metric_data(self, metric_name: str) -> pd.DataFrame:
        """
        Get data for a specific metric.
        """
        return self._metrics_df[self._metrics_df['metric'] == metric_name].copy()

    def plot_all_metrics(self,
                         x_axis_label: str = "Episodes",
                         smoothing_window: int = 50) -> None:
        """
        Plot all metrics stored in the tracker
        """
        # Get unique metric names
        metric_names = self._metrics_df['metric'].unique()
        
        for metric_name in metric_names:
            self.plot_metric(metric_name,
                             f"{metric_name}_plot",
                             x_axis_label,
                             y_axis_label=f"{metric_name} Mean ± SE",
                             title=" ",
                             smoothing_window=smoothing_window)

    def plot_metric(self,
                    metric_name: str,
                    file_name: str,
                    x_axis_label: str = "Episodes",
                    y_axis_label: str = "Metric Value",
                    title: str = None,
                    smoothing_window: int = 50) -> None:
        """
        Plot the mean and standard error for a specific metric.
        """
        df = self._get_metric_data(metric_name)
        
        if df.empty:
            raise ValueError(f"Metric '{metric_name}' not found or has no data")
            
        # sort so rolling is applied in episode or timestep (idx) order within each run
        df = df.sort_values(['agent', 'run_id', 'idx'])

        # vectorized per-(agent,run) rolling mean
        df['value'] = (
            df.groupby(['agent', 'run_id'])['value']
            .transform(lambda x: x.rolling(window=smoothing_window, min_periods=1).mean())
        )
        
        # Create the plot
        sns.set_theme(style="darkgrid")
        plt.figure(figsize=(10, 8))
        
        ax = sns.lineplot(
            data=df, 
            x='idx', 
            y='value', 
            hue='agent',
            estimator='mean', 
            errorbar=('se', 1),
            linewidth=2.5
        )
        
        ax.set_title(title or f'{metric_name.capitalize()} Mean ± Standard Error', fontsize=18)
        ax.set_xlabel(x_axis_label, fontsize=16)
        ax.set_ylabel(y_axis_label, fontsize=16)
        ax.tick_params(axis='both', which='major', labelsize=14)
        ax.legend(fontsize=14)
        ax.grid(True, which='both', linestyle='--', linewidth=0.6, alpha=0.6)
        
        # Ensure x-axis ticks are integers
        ax.xaxis.set_major_locator(MaxNLocator(integer=True))
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.save_path, file_name))
        plt.close()

    def clear_metrics(self) -> None:
        """Clear all recorded metrics"""
        self._metrics_df = pd.DataFrame(columns=['metric', 'agent', 'idx', 'value', 'run_id'])
        self._next_run_id = 0
        self._data_cache.clear()

    def export_metrics_csv(self, file_path: str) -> None:
        """
        Export metrics to a CSV file
        """
        self._metrics_df.to_csv(file_path, index=False)

    def import_metrics_csv(self, file_path: str) -> None:
        """
        Import metrics from a CSV file (efficient implementation)
        """
        df = pd.read_csv(file_path)
        
        # Validate required columns
        required_columns = ['metric', 'agent', 'idx', 'value']
        if not all(col in df.columns for col in required_columns):
            raise ValueError("CSV file must contain columns: metric, agent, idx, value")
        
        # Ensure run_id column exists, create if not
        if 'run_id' not in df.columns:
            # Group by metric, agent, idx to assign run IDs
            df['run_id'] = df.groupby(['metric', 'agent', 'idx']).cumcount()
        
        # Update the next run ID
        if 'run_id' in df.columns:
            self._next_run_id = df['run_id'].max() + 1
        
        # Replace the current DataFrame
        self._metrics_df = df
        self._data_cache.clear()

    def get_metrics_summary(self) -> pd.DataFrame:
        """
        Get a summary of all metrics with mean and standard error
        """
        if self._metrics_df.empty:
            return pd.DataFrame()
        
        summary = self._metrics_df.groupby(['metric', 'agent', 'idx']).agg(
            mean=('value', 'mean'),
            std=('value', 'std'),
            count=('value', 'count')
        ).reset_index()
        
        summary['se'] = summary['std'] / np.sqrt(summary['count'])
        summary['lower'] = summary['mean'] - summary['se']
        summary['upper'] = summary['mean'] + summary['se']
        
        return summary


if __name__ == "__main__":
    # Example usage with dummy data
    tracker = MetricsTracker()
    tracker.set_save_path("./")

    agents = ["AgentA", "AgentB"]
    num_episodes = 100

    np.random.seed(42)
    for run in range(5):
        tracker.start_new_run()
        for agent in agents:
            for ep in range(1, num_episodes + 1):
                loss_value = np.random.normal(loc=100 - ep * 0.5, scale=5)
                return_value = np.random.normal(loc=ep * 1.5, scale=10)
                tracker.record_metric("return", agent, ep, return_value)

    tracker.export_metrics_csv("metrics_export.csv")
    
    tracker2 = MetricsTracker()
    tracker2.import_metrics_csv("metrics_export.csv")
    
    tracker2.plot_metric("return", "return_plot_from_csv.png", smoothing_window=50)
    
    summary = tracker2.get_metrics_summary()
    print(summary.head())