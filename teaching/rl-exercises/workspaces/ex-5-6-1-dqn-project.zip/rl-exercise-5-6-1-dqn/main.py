import copy
import gymnasium as gym
from loguru import logger
from stable_baselines3 import DQN
from stable_baselines3.common.callbacks import StopTrainingOnMaxEpisodes
from algorithms.control.double_q_learning_agent import DoubleQLearningAgent
from algorithms.control.q_learning_agent import QLearningAgent
from algorithms.control.randomagent import RandomAgent
from algorithms.control.sarsa_agent import SarsaAgent
from util.earlystopcallback import EarlyStopOnNegativeRewardCallback
from util.evaluation import evaluate_target_policy
from util.metrictracker import MetricsTracker
from util.offpolicymetricstrackercallback import OffPolicyMetricsTrackerCallback


def env_interaction(env_str: str,
                    agent_type: str,
                    num_episodes: int,
                    behavioral_tracker: MetricsTracker,
                    target_tracker: MetricsTracker,
                    epsilon: float,
                    learning_rate: float) -> None:
    """
    Train your tabular algorithms here and track performance using MetricsTracker.
    """
    logger.info(f"Training {agent_type} on {env_str} for {num_episodes} episodes.")

    # Create environment and a copy for evaluation purposes
    env = gym.make(env_str, render_mode='rgb_array', max_episode_steps=1_00)
    eval_env = copy.deepcopy(env)

    # Instantiate our RL agent
    obs_space = env.observation_space
    action_space = env.action_space
    agent = None
    if agent_type == "SARSA":
        agent = SarsaAgent(obs_space, action_space, epsilon=epsilon, learning_rate=learning_rate)
    elif agent_type == "Q-LEARNING":
        agent = QLearningAgent(obs_space, action_space, epsilon=epsilon, learning_rate=learning_rate)
    elif agent_type == "DOUBLE-Q-LEARNING":
        agent = DoubleQLearningAgent(obs_space, action_space, epsilon=epsilon, learning_rate=learning_rate)
    elif agent_type == "RANDOM":
        agent = RandomAgent(obs_space, action_space)
    else:
        raise ValueError("Unsupported agent type")

    for episode in range(num_episodes):
        episode_return = 0
        obs, info = env.reset()

        # Start episode loop
        while True:
            action = agent.behavior_policy(obs)
            next_obs, reward, terminated, truncated, info = env.step(action)

            # Consider falling from the Cliff as a terminal state
            if reward == -100:
                terminated = True

            agent.update((obs, action, reward, next_obs))

            episode_return += reward
            obs = next_obs

            if terminated or truncated:
                # Record episodic return for the behavioral policy
                behavioral_tracker.record_metric(
                    metric_name="return",
                    agent_id=agent.agent_type,
                    idx=episode,
                    value=episode_return
                )

                # Evaluate target policy and record its return
                evaluate_target_policy(eval_env, agent, target_tracker, episode_idx=episode)
                break

    env.close()
    eval_env.close()


def train_dqn(env_str: str,
              behavioral_tracker: MetricsTracker,
              target_tracker: MetricsTracker,
              num_episodes: int) -> None:
    """
    Train your DQN algorithm here and track performance using MetricsTracker.
    Use the MetricsTrackerCallback, S and EarlyStopOnNegativeRewardCallback when running the learn method.
    """
    logger.info(f"Training DQN on {env_str}")

    env = gym.make(env_str, render_mode='rgb_array', max_episode_steps=1_00)
    eval_env = copy.deepcopy(env)

    # Define the callbacks
    metrics_tracker_callback = OffPolicyMetricsTrackerCallback(
        behavioral_tracker=behavioral_tracker,
        target_tracker=target_tracker,
        eval_env=eval_env
    )
    # Consider falling from the Cliff as a terminal state
    early_stop_callback = EarlyStopOnNegativeRewardCallback(stop_reward=-100)
    # Can be used to limit the number of episodes trained as the learn method takes in the
    # number of timesteps to train for instead of episodes.
    max_episode_callback = StopTrainingOnMaxEpisodes(max_episodes=num_episodes, verbose=0)

    # Add code here

    env.close()
    eval_env.close()


if __name__ == "__main__":
    tracker_behavior = MetricsTracker()
    tracker_target = MetricsTracker()

    # For larger experiments you would want more sophisticated config
    # management using config files but for simplicity we define them here.
    num_runs = 1
    n_episodes = 40
    for _ in range(num_runs):
        tracker_behavior.start_new_run()
        tracker_target.start_new_run()
        # Train each algorithm per run. `env_interaction` for tabular algorithms and `train_dqn` for DQN.

    tracker_behavior.export_metrics_csv("tracker_behavior")
    # tracker_target.export_metrics_csv("tracker_target")
    
    tracker_behavior.plot_metric("return", "return_behavior.png")
    # tracker_target.plot_metric("return", "return_target.png")
