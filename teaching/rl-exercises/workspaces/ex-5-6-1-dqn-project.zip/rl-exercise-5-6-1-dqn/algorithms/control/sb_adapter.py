from stable_baselines3.common.base_class import BaseAlgorithm


class StableBaselinesAdapter:
    """
    Adapter class to use Off-Policy Stable Baselines models as agents.
    For simplicity this is not inheriting from any class
    but it does share an interface with TabularAgent.
    """

    def __init__(self, model: BaseAlgorithm) -> None:
        """
        Constructor for StableBaselinesAdapter.

        :param model: Stable Baselines model to adapt.
        """
        super().__init__()
        self._sb_model = model

    def update(self, transition: tuple) -> None:
        # Stable Baselines handles its own training, so nothing to implement here.
        pass

    def target_policy(self, state) -> int:
        """
        Returns the action from the Stable Baselines model's learned policy,
        representing the target policy (typically deterministic during evaluation).

        :param state: The current state of the environment.
        :return: Action chosen by the policy (deterministic action).
        """
        action, _states = self._sb_model.predict(state, deterministic=True)
        return int(action)

    def behavior_policy(self, state) -> int:
        """
        Returns the action from the Stable Baselines model's behavior policy.
        The behavior policy may use exploration (stochastic action selection).

        :param state: The current state of the environment.
        :return: Action chosen by the policy (stochastic action).
        """
        action, _states = self._sb_model.predict(state, deterministic=False)
        return int(action)
