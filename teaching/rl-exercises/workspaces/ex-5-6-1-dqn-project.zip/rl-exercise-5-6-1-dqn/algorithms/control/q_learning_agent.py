import numpy as np
from algorithms.control.tabularagent import TabularAgent

class QLearningAgent(TabularAgent):
    def __init__(self, state_space, action_space, learning_rate=0.1, discount_factor=0.9, epsilon=0.1):
        super().__init__(state_space, action_space, learning_rate, discount_factor)
        self.epsilon = epsilon
        self.agent_type = 'Q-LEARNING'

    def update(self, transition: tuple) -> None:
        raise NotImplementedError("Implement Q-learning update rule.")

    def behavior_policy(self, state) -> int:
        raise NotImplementedError("Implement behavior_policy.")

    def target_policy(self, state) -> int:
        raise NotImplementedError("Implement target_policy.")
