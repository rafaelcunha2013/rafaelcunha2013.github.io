from algorithms.control.tabularagent import TabularAgent


class RandomAgent(TabularAgent):
    def __init__(self,
                 state_space,
                 action_space):
        """
        Agent Base Class constructor.

        :param state_space: State space of the gym environment.
        :param action_space: Action space of the gym environment.
        """
        self.state_space = state_space
        self.action_space = action_space

    def update(self, *args, **kwargs) -> None:
        pass

    def policy(self, *args, **kwargs):
        return self.env_action_space.sample()
