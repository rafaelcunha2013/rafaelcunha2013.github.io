from abc import ABC, abstractmethod
import numpy as np
import gymnasium as gym


class TabularAgent(ABC):
    """
    Agent abstract base class.
    """

    def __init__(self,
                 state_space: gym.spaces.Discrete,
                 action_space: gym.spaces.Discrete,
                 learning_rate=0.1,
                 discount_factor=0.9):
        """
        Agent Base Class constructor.
        Assumes discrete gymnasium spaces.
        You may want to make these attributes private.
        :param state_space: state space of gymnasium environment.
        :param action_space: action space of gymnasium environment.
        :param learning_rate: of the underlying algorithm.
        :param discount_factor: discount factor (`gamma`).
        """
        self.q_table = np.zeros([state_space.n, action_space.n])
        self.env_action_space = action_space
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor


    @abstractmethod
    def update(self, transition: tuple) -> None:
        """
        Where the update rule is applied
        :param transition: (S, A, R, S') (Q-learning), (S, A, R, S', A') (SARSA).
        """
        pass

    # For the purposes of the assignment we make an explicit distinction between
    # The target and behavioral policy.
    # An alternative implementation would be to have a policy method with an
    # additional boolean parameter like 'determinstic=True'.

    @abstractmethod
    def behavior_policy(self, state) -> int:
        """
        This is where you would do action selection for the behavior.
        :param state:
        :return an action
        """
        pass

    @abstractmethod
    def target_policy(self, state) -> int:
        """
        This is where you would do action selection for the target policy.
        :param state:
        :return an action
        """
        pass

