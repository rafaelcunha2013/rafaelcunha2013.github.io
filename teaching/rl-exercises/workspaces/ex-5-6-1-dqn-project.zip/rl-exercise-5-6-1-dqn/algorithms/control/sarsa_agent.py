import numpy as np
from algorithms.control.tabularagent import TabularAgent


class SarsaAgent(TabularAgent):
    def __init__(self, state_space, action_space, learning_rate=0.1, discount_rate=0.9, epsilon=0.1):
        super().__init__(state_space, action_space, learning_rate, discount_rate)
        self.epsilon = epsilon
        self.agent_type = 'SARSA'

    def update(self, transition: tuple) -> None:
        # Hint: Run the behavior_policy here to get the next action A'.
        raise NotImplementedError("Implement SARSA update rule.")

    def behavior_policy(self, state) -> int:
        raise NotImplementedError("Implement behavior_policy.")

    def target_policy(self, state) -> int:
        return self.behavior_policy(state)
