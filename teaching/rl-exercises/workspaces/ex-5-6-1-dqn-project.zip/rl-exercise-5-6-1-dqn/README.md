
## About
This repository contains the implementation of RL algorithms.

## Getting started

### Prerequisites

- [GCC](https://gcc.gnu.org/) (a C++ compiler) - if you are using an environment that requires `box2d-py`.
- [Swig](https://swig.org/) - if you are using an environment that requires `box2d-py`.
- [UV package manager](https://docs.astral.sh/uv/getting-started/installation/).

The first two dependencies are required for `box2d-py` which some gymnasium environments use to render the environment.

## Running
<!--
-->

### Setting up a virtual environment

**[uv](https://github.com/astral-sh/uv)** is a Python package installer and project manager.
Think of it as a drop-in replacement for tools like `pip`, `pip-tools`, and `poetry`.

You can install uv globally (see also the installation instructions [here](https://docs.astral.sh/uv/#__tabbed_1_2)):

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```
For Windows:
```
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

Check installation:

```bash
uv --version
```

---

#### Managing Dependencies

Install all dependencies:
```bash
uv sync
```

Adding dependencies:
```bash
uv add <package_name>
```

This ensures `.venv` (or `__pypackages__`) matches your `uv.lock`.

---

## Running the project

To run the project, you can use uv:
```bash
uv run python <script_name>
```

Alternatively, you can activate the virtual environment and run Python scripts directly:
```bash
source .venv/bin/activate
python <script_name>
```

## Installing GCC and Swig

GCC stands for the GNU Compiler Collection and includes compilers for C and C++. To install GCC (assuming a Debian-based Linux distribution like Ubuntu):
```
apt-get install build-essential
```
For `swig`:
```
apt-get install swig
```
