import numpy as np
from mdp.mdp import MDP
from util.discretepolicy import DiscretePolicy


class BellmanEquationSolver:
    """"
    Implements the matrix solution for policy evaluation.
    """

    def __init__(self, mdp: MDP):
        """
        Initializes the Bellman Equation Solver for the given MDP.

        :param mdp: An instance of a class that implements MDP.
        """
        self.mdp = mdp

    def policy_evaluation(self, policy: DiscretePolicy) -> np.ndarray:
        """
        Evaluates the value function for a given policy using the direct matrix method.

        :param policy: An instance of the Policy class, which provides the action probabilities for each state.
        :return: A NumPy array representing the value function for the given policy.
        """
        pass
