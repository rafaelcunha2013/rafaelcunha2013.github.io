from algorithms.solvers.bellmanequationsolver import BellmanEquationSolver
from util.assignment2_mdp import create_mdp_assignment2
from util.mdp_util import create_stochastic_policy


def main() -> None:
    """
    Starting point of the program, you can instantiate any classes, run methods/functions here as needed.
    """
    mdp = create_mdp_assignment2()  # Create the MDP from the question.

    print("Running Matrix Solution for Policy Evaluation...")
    solver = BellmanEquationSolver(mdp)
    # Example policy for policy evaluation
    policy = create_stochastic_policy()
    value_function = solver.policy_evaluation(policy)
    print("Value Function for given Policy:", value_function)

if __name__ == "__main__":
    main()
