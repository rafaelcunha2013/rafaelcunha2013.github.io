"""The MDP of Figure 1 (Exercise 2.6.2, part (f)): your code."""
import numpy as np
from mdp.mdp import MDP
from mdp.reward_function import RewardFunction
from mdp.transition_function import TransitionFunction


def create_mdp_assignment2() -> MDP:
    """
    Creates the MDP of Figure 1 (Exercise 2.6.2, part (f)).

    :return: An MDP object with the states, actions, transition function, reward function and
        discount factor of Figure 1.
    """
    pass
