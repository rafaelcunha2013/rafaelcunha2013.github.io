from matplotlib import pyplot as plt
import numpy as np
from mdp.mdp import MDP
from mdp.reward_function import RewardFunction
from mdp.transition_function import TransitionFunction
from util.discretepolicy import DiscretePolicy

"""
MDP and policies assignment 2
"""

def create_stochastic_policy(num_states: int = 3) -> DiscretePolicy:
    """
    Factory function to create a Policy object with a predefined stochastic policy.

    :param num_states: Number of states in the MDP.
    :return: A Policy object with the desired stochastic properties.
    """
    policy = DiscretePolicy()

    for state in range(num_states):
        # Set probabilities for actions: 0.4 for a_1 and 0.6 for a_2.
        action_probabilities = [0.4, 0.6]  # Adjust if the number of actions differs.
        policy.set_action_probabilities(state, action_probabilities)

    return policy
