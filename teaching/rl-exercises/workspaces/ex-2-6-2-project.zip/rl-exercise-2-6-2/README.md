
## About
This repository contains code for the second assignment.

## Getting started

### Prerequisites

- [UV package manager](https://docs.astral.sh/uv/getting-started/installation/).

## Running
<!--
-->

### Setting up a virtual environment

**[uv](https://github.com/astral-sh/uv)** is a Python package installer and project manager.
Think of it as a drop-in replacement for tools like `pip`, `pip-tools`, and `poetry`.


You can install uv globally:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```
Check installation:

```bash
uv --version
```

---

#### Managing Dependencies

Install all dependencies:
```bash
uv sync
```

Adding dependencies:
```bash
uv add <package_name>
```

This ensures `.venv` (or `__pypackages__`) matches your `uv.lock`.

---

## Running the project

To run the project, you can use uv:
```bash
uv run python <script_name>
```

Alternatively, you can activate the virtual environment and run Python scripts directly:
```bash
source .venv/bin/activate
python <script_name>
```
