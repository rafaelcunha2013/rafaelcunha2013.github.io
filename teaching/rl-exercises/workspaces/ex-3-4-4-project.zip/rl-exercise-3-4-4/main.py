import argparse
from algorithms.solvers.dynamicprogrammingsolver import DynamicProgrammingSolver
from util.mdp_util import create_mdp_assignment2, create_stochastic_policy


def parse_args() -> argparse.Namespace:
    # Create an argument parser
    parser = argparse.ArgumentParser(
        description='MDP Solver using Value Iteration, Policy Iteration')
    parser.add_argument('method', choices=['value_iter', 'policy_iter',
                                           'policy_eval'],
                        help='Method to use for solving the MDP.')
    parser.add_argument('--gamma', type=float, default=0.9, help='Discount factor (default: 0.9)')
    parser.add_argument('--theta', type=float, default=1e-6,
                        help='Convergence threshold for value iteration (default: 1e-6)')

    return parser.parse_args()


def main() -> None:
    """
    Starting point of the program, you can instantiate any classes, run methods/functions here as needed.
    """
    args = parse_args()  # Run the parser.

    mdp = create_mdp_assignment2()  # Create the MDP from the question.

    if args.method == 'value_iter':
        print("Running Value Iteration...")
        solver = DynamicProgrammingSolver(mdp, args.theta)
        optimal_policy, value_function = solver.value_iteration()
        print("Optimal Policy:", optimal_policy)
        print("Optimal Value Function:", value_function)
    elif args.method == 'policy_iter':
        print("Running Policy Iteration...")
        solver = DynamicProgrammingSolver(mdp, args.theta)
        optimal_policy, value_function = solver.policy_iteration()
        print("Optimal Policy:", optimal_policy)
        print("Optimal Value Function:", value_function)
    elif args.method == "policy_eval":
        print("Running Iterative Policy Evaluation...")
        solver = DynamicProgrammingSolver(mdp)
        # Example policy for policy evaluation
        policy = create_stochastic_policy()
        value_function = solver.iterative_policy_evaluation(policy)
        print("Value Function for given Policy:", value_function)


if __name__ == "__main__":
    main()
