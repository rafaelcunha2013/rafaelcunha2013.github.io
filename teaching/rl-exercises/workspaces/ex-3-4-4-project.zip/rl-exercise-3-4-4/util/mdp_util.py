from matplotlib import pyplot as plt
import numpy as np
from mdp.mdp import MDP
from mdp.reward_function import RewardFunction
from mdp.transition_function import TransitionFunction
from util.discretepolicy import DiscretePolicy

"""
MDP and policies assignment 2 & 3
"""
def create_mdp_assignment2() -> MDP:
    # Corrected rewards for the updated reward table
    rewards = {
        (0, 0): -0.9,  # s_0 to s_2 (a_1) -> R_t = -0.9
        (0, 1): -0.9,  # s_0 to s_1 (a_2) -> R_t = -0.9
        (1, 0): -0.1,  # s_1 to s_0 (a_1) -> R_t = -0.1
        (1, 1): -0.1,  # s_1 to s_0 (a_2) -> R_t = -0.1
        (2, 0): -1,  # s_2 to s_1 (a_1) -> R_t = -1
        (2, 1): -0.1,  # s_2 to s_0 (a_2) -> R_t = -0.1
    }

    reward_function = RewardFunction(rewards)

    # Updated transitions based on the provided table and corrections
    transitions = {
        # State 0
        (0, 0): np.array([0.1, 0.0, 0.9]),  # Action 1 in State 0: 10% to stay, 90% to state 2
        (0, 1): np.array([0.1, 0.9, 0.0]),  # Action 2 in State 0: 10% to stay, 90% to state 1

        # State 1
        (1, 0): np.array([0.9, 0.1, 0.0]),  # Action 1 in State 1: 90% to state 0, 10% to stay
        (1, 1): np.array([0.9, 0.1, 0.0]),  # Action 2 in State 1: 90% to state 0, 10% to stay

        # State 2
        (2, 0): np.array([0.0, 0.9, 0.1]),  # Action 1 in State 2: 90% to state 1, 10% to stay
        (2, 1): np.array([0.9, 0.0, 0.1])  # Action 2 in State 2: 90% to state 0, 10% to stay
    }

    # Create the TransitionFunction object
    transition_function = TransitionFunction(transitions)

    return MDP(states=[0, 1, 2],
               actions=[0, 1],
               transition_function=transition_function,
               reward_function=reward_function,
               discount_factor=0.9)


def create_stochastic_policy(num_states: int = 3) -> DiscretePolicy:
    """
    Factory function to create a Policy object with a predefined stochastic policy.

    :param num_states: Number of states in the MDP.
    :return: A Policy object with the desired stochastic properties.
    """
    policy = DiscretePolicy()

    for state in range(num_states):
        # Set probabilities for actions: 0.4 for a_1 and 0.6 for a_2.
        action_probabilities = [0.4, 0.6]  # Adjust if the number of actions differs.
        policy.set_action_probabilities(state, action_probabilities)

    return policy
