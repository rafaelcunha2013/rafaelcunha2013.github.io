from typing import Tuple
import numpy as np
from mdp.mdp import MDP
from util.discretepolicy import DiscretePolicy


class DynamicProgrammingSolver:
    """
    Implements the value iteration and policy iteration algorithm.
    The policy iteration method contains an iterative policy evaluation routine.
    """

    def __init__(self, mdp: MDP, theta: float = 1e-6):
        """
        Initializes the Dynamic Programming Solver for the given MDP.

        :param mdp: An instance of a class that implements MDP.
        :param theta: Convergence threshold for iterative methods.
        """
        self.mdp = mdp
        self.theta = theta

    def value_iteration(self) -> Tuple[DiscretePolicy, np.ndarray]:
        """
        Finds the optimal policy using Value Iteration.

        :return: An optimal policy and optimal value function.
        """
        pass

    def policy_iteration(self) -> Tuple[DiscretePolicy, np.ndarray]:
        """
        Performs policy iteration to find the optimal policy.

        :return: An optimal policy and optimal value function.
        """
        pass

    def iterative_policy_evaluation(self, policy: DiscretePolicy) -> np.ndarray:
        """
        Evaluates the value function for a given policy using the iterative method.

        :param policy: An instance of the Policy class, which provides the action probabilities for each state.
        :param theta: Convergence threshold.
        :return: A NumPy array representing the value function for the given policy.
        """
        pass

    def policy_improvement(self, value_vec: np.ndarray) -> np.ndarray:
        """
        Performs policy improvement on a given policy.

        :param value_vec: A NumPy array representing the value function for the given policy.
        :return: A NumPy array where each element represents the improved action to take for each state.
        """
        pass
