import numpy as np
from mdp.mdp import MDP
from util.discretepolicy import DiscretePolicy


class TDLambdaEvaluator:
    def __init__(self,
                 env: MDP,
                 alpha: float = 0.1,
                 lambd: float = 0.5):
        """
        Initializes the TD(λ) Learner.

        :param env: A mdp object.
        :param alpha: The step size (learning rate).
        :param lambd: The trace decay parameter (λ).
        """
        self.env = env
        self.alpha = alpha
        self.lambd = lambd
        self.value_fun = np.zeros(self.env.num_states)
        self.eligibility_traces = np.zeros(self.env.num_states)

    def evaluate(self, policy: DiscretePolicy, num_episodes: int) -> np.ndarray:
        """
        Perform the TD prediction algorithm.

        :param policy: A policy object that provides action probabilities for each state.
        :param num_episodes: Number of episodes to run for estimating V(s).
        :return: The state-value function V(s) for the associated policy.
        """
        self.value_fun.fill(0)              # Reset value function.

        for _ in range(num_episodes):
            self._update_value_function(policy)

        return self.value_fun.copy()

    def _update_value_function(self, policy: DiscretePolicy) -> None:
        """
        Runs a single episode using the TD(λ) method to update the value function.
        """
        pass
