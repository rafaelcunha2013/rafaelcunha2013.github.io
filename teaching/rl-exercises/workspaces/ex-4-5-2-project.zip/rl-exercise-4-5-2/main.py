import argparse
import numpy as np
from algorithms.prediction.monte_carlo_evaluator import MCEvaluator
from algorithms.prediction.td_lambda_evaluator import TDLambdaEvaluator
from algorithms.prediction.td_evaluator import TDEvaluator
from util.mdp_util import create_mdp_assignment4, create_policy_1, create_policy_2

def parse_args() -> argparse.Namespace:
    # Create an argument parser
    parser = argparse.ArgumentParser(
        description='MDP Solver using Value Iteration, Policy Iteration, or Matrix Policy Evaluation.')
    parser.add_argument('method', choices=['mc_eval', 'td_eval', 'td_lambda_eval'],
                        help='Method to use for solving the MDP.')
    parser.add_argument('--gamma', type=float, default=0.9, help='Discount factor (default: 0.9)')
    parser.add_argument('--theta', type=float, default=1e-6,
                        help='Convergence threshold for value iteration (default: 1e-6)')
    parser.add_argument('--lambda', type=float, default=0.0,
                        help='Parameter lambda for TD(lambda) (default: 0.0)')

    return parser.parse_args()


def main() -> None:
    """
    Starting point of the program, you can instantiate any classes, run methods/functions here as needed.
    This should bebroken up into different functions but is kept like this for now.
    """
    np.random.seed(42)
    args = parse_args()  # Run the parser.

    mdp = create_mdp_assignment4()  # Create the MDP from the question.
    policy_1 = create_policy_1()
    policy_2 = create_policy_2()

    if args.method == 'mc_eval':
        evaluator = MCEvaluator(mdp)
        value_function_1 = evaluator.evaluate(policy_1, 1000)
        value_function_2 = evaluator.evaluate(policy_2, 1000)
        print("Value Function for Policy 1:", value_function_1)
        print("Value Function for Policy 2:", value_function_2)
    elif args.method == 'td_eval':
        evaluator = TDEvaluator(mdp, alpha=0.1)  # TD(0).
        value_function_1 = evaluator.evaluate(policy_1, 1000)
        value_function_2 = evaluator.evaluate(policy_2, 1000)
        print("Value Function for Policy 1:", value_function_1)
        print("Value Function for Policy 2:", value_function_2)
    elif args.method == 'td_lambda_eval':
        evaluator = TDLambdaEvaluator(mdp, alpha=0.1, lambd=0.5)  # TD(0).
        value_function_1 = evaluator.evaluate(policy_1, 1000)
        value_function_2 = evaluator.evaluate(policy_2, 1000)
        print("Value Function for Policy 1:", value_function_1)
        print("Value Function for Policy 2:", value_function_2)


def experiment() -> None:
    np.random.seed(42)
    np.set_printoptions(precision=3, floatmode='fixed')
    env = create_mdp_assignment4()
    policy_1 = create_policy_1()
    policy_2 = create_policy_2()

    n_episodes = int(1e3)
    td_evaluator = TDLambdaEvaluator(env, alpha=0.1, lambd=0)
    value_func1 = td_evaluator.evaluate(policy_1, n_episodes)
    value_func2 = td_evaluator.evaluate(policy_2, n_episodes)
    print(f'TD(0) value function for policy 1: {value_func1}')
    print(f'TD(0) value function for policy 2: {value_func2}')

    td_lambda_evaluator = TDLambdaEvaluator(env, alpha=0.1, lambd=0.5)
    value_func1 = td_lambda_evaluator.evaluate(policy_1, n_episodes)
    value_func2 = td_lambda_evaluator.evaluate(policy_2, n_episodes)
    print(f'TD(0.5) value function for policy 1: {value_func1}')
    print(f'TD(0.5) value function for policy 2: {value_func2}')

    mc_evaluator = MCEvaluator(env)
    value_func1 = mc_evaluator.evaluate(policy_1, n_episodes)
    value_func2 = mc_evaluator.evaluate(policy_2, n_episodes)
    print(f'MC value function for policy 1: {value_func1}')
    print(f'MC value function for policy 2: {value_func2}')


if __name__ == "__main__":
    main()
